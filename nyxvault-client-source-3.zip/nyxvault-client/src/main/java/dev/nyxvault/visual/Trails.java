package dev.nyxvault.visual;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.combat.CombatState;
import net.minecraft.client.Minecraft;

/** Concrete trails sharing one implementation ({@link TrailModule}). */
public final class Trails {
    private Trails() { }

    /** Follows normal movement; stops recording when the player stands still so it fades out. */
    public static final class MotionTrail extends TrailModule {
        private double lastX, lastZ;

        public MotionTrail() {
            super("Motion Trail", "Crisp fading line behind you. Visual only; does not touch movement.",
                    Category.VISUALS, Style.GRADIENT, 0xFFA855F7, 0xFF3B82F6);
        }

        @Override protected boolean shouldRecord(Minecraft mc) {
            double dx = mc.player.getX() - lastX, dz = mc.player.getZ() - lastZ;
            lastX = mc.player.getX(); lastZ = mc.player.getZ();
            return dx * dx + dz * dz > 0.0001 || Math.abs(mc.player.getDeltaMovement().y) > 0.05;
        }
    }

    /** Separate trail that only records for a few seconds after you attack. */
    public static final class CombatTrail extends TrailModule {
        public CombatTrail() {
            super("Combat Trail", "Separate short trail shown only while you are fighting.",
                    Category.COMBAT, Style.RIBBON, 0xFF22D3EE, 0xFFA855F7);
        }

        @Override protected boolean shouldRecord(Minecraft mc) {
            return CombatState.lastAttackMs() != 0 && System.currentTimeMillis() - CombatState.lastAttackMs() < 3000;
        }
    }
}
