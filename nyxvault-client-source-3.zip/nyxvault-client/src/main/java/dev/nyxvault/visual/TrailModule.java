package dev.nyxvault.visual;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

/**
 * Crisp line-based trail following the player's recent path. Purely visual: it only reads the
 * player's position, never changes movement, physics or particles. It is drawn on the HUD layer
 * from projected points, so it is not depth-tested (it can show through blocks).
 */
public abstract class TrailModule extends OverlayModule {
    public enum Style { LINE, DOUBLE, RIBBON, GRADIENT, MINIMAL }

    private final EnumSetting<Style> style;
    private final ColorSetting color;
    private final ColorSetting color2;
    private final NumberSetting length;
    private final NumberSetting width;
    private final NumberSetting opacity;
    private final NumberSetting fade;
    private final BoolSetting firstPerson;
    private final BoolSetting thirdPerson;
    private final BoolSetting performance;

    private final TrailBuffer buf = new TrailBuffer(160);
    private double lx, ly, lz;
    private boolean hasLast;

    protected TrailModule(String name, String desc, Category cat, Style defStyle, int c1, int c2) {
        super(name, desc, cat);
        // Created in the constructor so the settings list keeps a sensible order and per-module defaults.
        this.style = add(new EnumSetting<>("Style", defStyle));
        this.color = add(new ColorSetting("Color", c1));
        this.color2 = add(new ColorSetting("Gradient Color", c2));
        this.length = add(NumberSetting.integer("Length", 40, 5, 150));
        this.width = add(NumberSetting.integer("Width", 2, 1, 6));
        this.opacity = add(NumberSetting.decimal("Opacity", 0.9, 0.1, 1.0, 0.05));
        this.fade = add(NumberSetting.integer("Fade Duration (ms)", 1200, 200, 5000));
        this.firstPerson = add(new BoolSetting("Show In First Person", true));
        this.thirdPerson = add(new BoolSetting("Show In Third Person", true));
        this.performance = add(new BoolSetting("Performance Mode", false));
    }

    /** Whether new trail points should be recorded this tick. */
    protected abstract boolean shouldRecord(Minecraft mc);

    @Override protected void onDisable() { buf.clear(); hasLast = false; }

    @Override
    public void onTick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        long now = System.currentTimeMillis();
        buf.prune(now, fade.asInt());
        if (!shouldRecord(mc)) return;
        double x = mc.player.getX(), y = mc.player.getY() + 0.05, z = mc.player.getZ();
        double dx = x - lx, dy = y - ly, dz = z - lz;
        if (!hasLast || dx * dx + dy * dy + dz * dz > 0.0004) {
            buf.add(x, y, z, now);
            lx = x; ly = y; lz = z; hasLast = true;
        }
    }

    @Override
    public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
        if (mc.player == null || buf.size() < 1) return;
        boolean first = mc.options.getCameraType().isFirstPerson();
        if (first ? !firstPerson.get() : !thirdPerson.get()) return;

        long now = System.currentTimeMillis();
        long fadeMs = fade.asInt();
        float perf = UiSettings.perfFactor() * (performance.get() ? 0.5f : 1f);
        int maxPts = Math.max(4, Math.round(length.asInt() * perf));
        int n = buf.size();
        int startI = Math.max(0, n - maxPts);
        Style st = style.get();
        int w = st == Style.MINIMAL ? 1 : width.asInt();
        float op = opacity.asFloat();
        int c1 = color.get(), c2 = color2.get();
        int count = n - startI;

        boolean have = false;
        float px = 0, py = 0, phx = 0, phy = 0;

        for (int i = startI; i <= n; i++) {
            double x, y, z;
            float t, a;
            if (i < n) {
                double age = now - buf.time(i);
                if (age > fadeMs) { have = false; continue; }
                x = buf.x(i); y = buf.y(i); z = buf.z(i);
                t = (i - startI) / (float) Math.max(1, count);
                a = (float) (1.0 - age / fadeMs) * Math.min(1f, t * 2.5f + 0.15f) * op;
            } else { // live head so the trail stays attached to the player
                float pt = delta.getGameTimeDeltaPartialTick(true);
                x = Mth.lerp(pt, mc.player.xo, mc.player.getX());
                y = Mth.lerp(pt, mc.player.yo, mc.player.getY()) + 0.05;
                z = Mth.lerp(pt, mc.player.zo, mc.player.getZ());
                t = 1f; a = op;
                if (!have) break;
            }
            if (!WorldProjector.project(x, y, z)) { have = false; continue; }
            float cx = WorldProjector.out[0], cy = WorldProjector.out[1];
            float hx = 0, hy = 0;
            if (st == Style.RIBBON) {
                if (!WorldProjector.project(x, y + 1.8, z)) { have = false; continue; }
                hx = WorldProjector.out[0]; hy = WorldProjector.out[1];
            }
            int col = Draw.alpha(st == Style.GRADIENT ? Draw.mix(c2, c1, t) : c1, a);
            if (have && WorldProjector.onScreen(60f)) {
                switch (st) {
                    case DOUBLE -> {
                        float dx = cx - px, dy = cy - py;
                        float len = (float) Math.sqrt(dx * dx + dy * dy);
                        if (len > 0.5f) {
                            float ox = -dy / len * (w + 1), oy = dx / len * (w + 1);
                            line(g, px + ox, py + oy, cx + ox, cy + oy, w, col);
                            line(g, px - ox, py - oy, cx - ox, cy - oy, w, col);
                        }
                    }
                    case RIBBON -> {
                        line(g, px, py, cx, cy, w, col);
                        line(g, phx, phy, hx, hy, w, col);
                        if ((i & 1) == 0) line(g, cx, cy, hx, hy, 1, Draw.alpha(col, 0.45f));
                    }
                    default -> line(g, px, py, cx, cy, w, col);
                }
            }
            px = cx; py = cy; phx = hx; phy = hy; have = true;
        }
    }

    /** Draws a crisp thick line out of small squares. */
    private static void line(GuiGraphics g, float x0, float y0, float x1, float y1, int w, int col) {
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.5f || len > 500f) return;
        int steps = Math.max(1, (int) (len / Math.max(1, w)));
        float sx = dx / steps, sy = dy / steps;
        float half = w * 0.5f;
        for (int s = 0; s <= steps; s++) {
            int ix = Math.round(x0 + sx * s - half), iy = Math.round(y0 + sy * s - half);
            g.fill(ix, iy, ix + w, iy + w, col);
        }
    }
}
