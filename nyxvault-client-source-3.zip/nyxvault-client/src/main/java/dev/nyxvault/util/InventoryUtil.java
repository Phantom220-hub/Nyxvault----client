package dev.nyxvault.util;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class InventoryUtil {
    private InventoryUtil() { }

    /** Total count of an item across the whole inventory (main, armor and offhand slots). */
    public static int count(Player p, Item item) {
        Inventory inv = p.getInventory();
        int c = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() == item) c += s.getCount();
        }
        return c;
    }
}
