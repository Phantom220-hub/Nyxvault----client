package dev.nyxvault.util;

import java.util.ArrayList;
import java.util.List;

/**
 * On-screen notifications plus bounded history. Accessed only from the client thread.
 * Identical messages are merged (refreshed) instead of stacked, and higher priority messages sort first.
 */
public final class Notifications {
    public record Entry(String text, long createdMs, int priority) { }

    private static final int MAX_HISTORY = 50;
    private static final int MAX_ACTIVE = 5;
    /** How long a notification stays visible (set from the Interface module). */
    public static volatile long lifetime = 3500;
    private static final List<Entry> active = new ArrayList<>();
    private static final List<Entry> history = new ArrayList<>();

    private Notifications() { }

    public static void push(String text) { push(text, 0); }

    /** @param priority 0 = normal, 1 = important (shown first). */
    public static void push(String text, int priority) {
        long now = System.currentTimeMillis();
        Entry e = new Entry(text, now, priority);
        boolean merged = false;
        for (int i = 0; i < active.size(); i++) {
            if (active.get(i).text().equals(text)) { active.set(i, e); merged = true; break; }
        }
        if (!merged) {
            active.add(e);
            history.add(e);
            if (history.size() > MAX_HISTORY) history.remove(0);
        }
        active.sort((a, b) -> a.priority() != b.priority()
                ? Integer.compare(b.priority(), a.priority())
                : Long.compare(a.createdMs(), b.createdMs()));
        while (active.size() > MAX_ACTIVE) active.remove(active.size() - 1);
    }

    public static void prune() {
        long now = System.currentTimeMillis();
        active.removeIf(e -> now - e.createdMs() > lifetime);
    }

    public static List<Entry> active() { return new ArrayList<>(active); }
    public static List<Entry> history() { return List.copyOf(history); }
    public static long lifetimeMs() { return lifetime; }
}
