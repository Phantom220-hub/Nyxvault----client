package dev.nyxvault.module;

import dev.nyxvault.setting.Setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Base module: name, description, category, enabled state, keybind and typed settings. */
public abstract class Module {
    private final String name;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int key = -1; // GLFW key code, -1 = unbound
    /** Animation progress 0..1 used by the GUI toggle switch. */
    public float anim;
    /** Animation progress 0..1 used by the module list overlay (smooth enter/exit). */
    public float listAnim;

    protected Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    protected <S extends Setting<?>> S add(S setting) {
        settings.add(setting);
        return setting;
    }

    public String name() { return name; }
    public String description() { return description; }
    public Category category() { return category; }
    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    public boolean enabled() { return enabled; }
    public int key() { return key; }
    public void setKey(int key) { this.key = key; }
    /** Whether the panic key may disable this module. */
    public boolean panicEligible() { return true; }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            dev.nyxvault.NyxvaultClient.LOGGER.error("Module {} failed on {}", name, value ? "enable" : "disable", t);
        }
    }

    public void toggle() { setEnabled(!enabled); }

    public void resetSettings() { settings.forEach(Setting::reset); }

    /** Restores enabled state from config without a spurious lifecycle failure. */
    public void restoreEnabled(boolean value) { setEnabled(value); }

    protected void onEnable() { }
    protected void onDisable() { }
    /** Called each client tick while enabled and a world is loaded. */
    public void onTick() { }
}
