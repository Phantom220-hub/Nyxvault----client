package dev.nyxvault.module.combat;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.hud.HudModule;
import dev.nyxvault.hud.OverlayModule;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Client-side combat feedback. None of these modify attacks, reach or aim. */
public final class CombatModules {
    private CombatModules() { }

    public static final class Crosshair extends OverlayModule {
        public enum Style { CROSS, DOT, PLUS_DOT, CIRCLE }

        private final EnumSetting<Style> style = add(new EnumSetting<>("Style", Style.CROSS));
        private final ColorSetting color = add(new ColorSetting("Color", 0xFFA855F7));
        private final NumberSetting size = add(NumberSetting.integer("Size", 5, 1, 20));
        private final NumberSetting gap = add(NumberSetting.integer("Gap", 2, 0, 15));
        private final NumberSetting thickness = add(NumberSetting.integer("Thickness", 1, 1, 5));
        private final BoolSetting dynamic = add(new BoolSetting("Dynamic States", true));
        private final ColorSetting targetColor = add(new ColorSetting("Target Color", 0xFFEF4444));

        public Crosshair() { super("Custom Crosshair", "Draws an extra configurable crosshair (the vanilla one stays visible).", Category.COMBAT); }

        @Override public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
            if (mc.player == null || !mc.options.getCameraType().isFirstPerson()) return;
            int cx = mc.getWindow().getGuiScaledWidth() / 2, cy = mc.getWindow().getGuiScaledHeight() / 2;
            int c = color.get(), s = size.asInt(), gp = gap.asInt(), t = thickness.asInt(), h = t / 2;
            if (dynamic.get()) {
                // Reliable client state only: a living entity under the crosshair, attack cooldown, sprinting.
                if (mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.ENTITY
                        && ((EntityHitResult) mc.hitResult).getEntity() instanceof LivingEntity) c = targetColor.get();
                float cd = mc.player.getAttackStrengthScale(0f);
                if (cd < 1f) gp += Math.round((1f - cd) * 4f);
                if (mc.player.isSprinting()) gp += 1;
            }
            switch (style.get()) {
                case DOT -> g.fill(cx - h, cy - h, cx - h + t, cy - h + t, c);
                case CIRCLE -> {
                    int r = s + gp;
                    for (int i = 0; i < 24; i++) {
                        double a = i * Math.PI / 12;
                        int px = cx + (int) Math.round(Math.cos(a) * r), py = cy + (int) Math.round(Math.sin(a) * r);
                        g.fill(px, py, px + t, py + t, c);
                    }
                }
                default -> {
                    g.fill(cx - h, cy - gp - s, cx - h + t, cy - gp, c);
                    g.fill(cx - h, cy + gp, cx - h + t, cy + gp + s, c);
                    g.fill(cx - gp - s, cy - h, cx - gp, cy - h + t, c);
                    g.fill(cx + gp, cy - h, cx + gp + s, cy - h + t, c);
                    if (style.get() == Style.PLUS_DOT) g.fill(cx - h, cy - h, cx - h + t, cy - h + t, c);
                }
            }
        }
    }

    public static final class HitMarker extends OverlayModule {
        private final ColorSetting color = add(new ColorSetting("Color", 0xFFA855F7));
        private final NumberSetting duration = add(NumberSetting.integer("Duration (ms)", 350, 100, 1500));
        private final NumberSetting size = add(NumberSetting.integer("Size", 8, 3, 30));
        private final BoolSetting ring = add(new BoolSetting("Expanding Ring", true));
        private final BoolSetting reduced = add(new BoolSetting("Reduced Effects (no ring)", false));

        public HitMarker() { super("Hit Marker", "Four-segment marker when the client sees your target get hurt.", Category.COMBAT); }

        @Override public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
            long age = System.currentTimeMillis() - CombatState.confirmedHitMs();
            int dur = duration.asInt();
            if (CombatState.confirmedHitMs() == 0 || age > dur) return;
            float p = age / (float) dur;
            float fade = 1f - p;
            int cx = mc.getWindow().getGuiScaledWidth() / 2, cy = mc.getWindow().getGuiScaledHeight() / 2;
            int c = Draw.alpha(color.get(), fade);
            int s = size.asInt(), gp = 3 + Math.round(p * 3);
            for (int i = 1; i <= s / 2 + 2; i++) { // diagonal segments in four directions
                int d = gp + i;
                g.fill(cx - d, cy - d, cx - d + 1, cy - d + 1, c);
                g.fill(cx + d, cy - d, cx + d + 1, cy - d + 1, c);
                g.fill(cx - d, cy + d, cx - d + 1, cy + d + 1, c);
                g.fill(cx + d, cy + d, cx + d + 1, cy + d + 1, c);
            }
            if (ring.get() && !reduced.get() && !UiSettings.reducedEffects) {
                int r = s + Math.round(p * s * 2);
                int rc = Draw.alpha(UiSettings.secondary(), fade * 0.7f);
                for (int i = 0; i < 20; i++) {
                    double a = i * Math.PI / 10;
                    int px = cx + (int) Math.round(Math.cos(a) * r), py = cy + (int) Math.round(Math.sin(a) * r);
                    g.fill(px, py, px + 1, py + 1, rc);
                }
            }
        }
    }

    public static final class TargetHud extends HudModule {
        private float shownHealth = -1f;

        public TargetHud() { super("Target HUD", "Name, health, distance and armor of your last attack target.", Category.COMBAT, 300, 200); }

        @Override public int width(Minecraft mc) { return 110; }
        @Override public int height(Minecraft mc) { return 34; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            LivingEntity t = CombatState.target(5000);
            boolean preview = t == null;
            Draw.round(g, 0, 0, width(mc), height(mc), a(UiSettings.theme.background));
            Draw.border(g, 0, 0, width(mc), height(mc), a(UiSettings.accent()));
            if (preview) {
                g.drawString(mc.font, "No target", 6, 12, a(0xFF9CA3AF), true);
                shownHealth = -1f;
                return;
            }
            float hp = Math.max(0f, t.getHealth()), max = Math.max(1f, t.getMaxHealth());
            shownHealth = shownHealth < 0 ? hp : Draw.approach(shownHealth, hp, 10f, 1f / Math.max(1, mc.getFps()));
            g.drawString(mc.font, t.getName().getString(), 6, 4, a(0xFFFFFFFF), true);
            g.fill(6, 15, 104, 21, a(0xFF1F2937));
            g.fill(6, 15, 6 + Math.round(98 * Math.min(1f, shownHealth / max)), 21, a(UiSettings.accent()));
            double d = mc.player.distanceTo(t);
            String extra = String.format("%.1f/%.0f  %.1fm", hp, max, d);
            if (t instanceof Player) extra += "  AR " + t.getArmorValue();
            g.drawString(mc.font, extra, 6, 24, a(0xFFD1D5DB), true);
        }
    }
}
