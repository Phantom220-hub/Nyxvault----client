package dev.nyxvault.module.combat;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.util.InventoryUtil;
import dev.nyxvault.util.SessionStats;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

public final class TotemModules {
    private TotemModules() { }

    /**
     * Shared totem bookkeeping, updated every tick.
     * Pop detection is a client-side heuristic: a totem disappeared from the inventory while the
     * player was taking damage and no screen was open. It only detects YOUR OWN pops.
     */
    public static final class Tracker {
        private static int count;
        private static int prev = -1;
        private static long lastPopMs;

        private Tracker() { }

        public static void tick(Minecraft mc) {
            Player p = mc.player;
            if (p == null) { prev = -1; count = 0; return; }
            count = InventoryUtil.count(p, Items.TOTEM_OF_UNDYING);
            if (prev >= 0 && count < prev && mc.screen == null && p.isAlive()
                    && (p.hurtTime > 0 || p.getHealth() <= 4.0f)) {
                SessionStats.pops += prev - count;
                lastPopMs = System.currentTimeMillis();
            }
            prev = count;
        }

        /** Total totems in inventory including the offhand. */
        public static int count() { return count; }
        public static boolean offhandHasTotem() {
            Minecraft mc = Minecraft.getInstance();
            return mc.player != null && mc.player.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING;
        }
        public static long lastPopMs() { return lastPopMs; }
    }

    /**
     * Simple Auto Totem: when enabled, no screen is open and the offhand does not hold a totem,
     * swap one from the main inventory/hotbar into the offhand using a normal inventory click.
     * Note: this swaps whatever is in the offhand (for example a shield) out of it. Servers and
     * anti-cheats may restrict automated inventory actions; use it only where allowed.
     */
    public static final class AutoTotem extends Module {
        private int cooldown;

        public AutoTotem() {
            super("Auto Totem", "Moves a totem into the offhand when it is empty. Check server rules first.", Category.COMBAT);
        }

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
            if (cooldown > 0) { cooldown--; return; }
            if (p.getOffhandItem().getItem() == Items.TOTEM_OF_UNDYING) return;

            Inventory inv = p.getInventory();
            int found = -1;
            for (int i = 0; i < 36; i++) { // main inventory + hotbar only
                if (inv.getItem(i).getItem() == Items.TOTEM_OF_UNDYING) { found = i; break; }
            }
            if (found < 0) return;

            // InventoryMenu slot ids: 9-35 main inventory, 36-44 hotbar. Button 40 = swap with offhand.
            int slot = found < 9 ? 36 + found : found;
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, 40, ClickType.SWAP, p);
            cooldown = 6; // one action at a time; avoids conflicting clicks while the server confirms
        }
    }
}
