package dev.nyxvault.module.misc;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.render.Theme;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;

/** Theme, accent, animation, sound and scale settings for the interface. */
public final class InterfaceModule extends Module {
    private final EnumSetting<Theme> theme = add(new EnumSetting<>("Theme", Theme.NYXVAULT_SIGNATURE));
    private final BoolSetting customAccent = add(new BoolSetting("Custom Accent", false));
    private final ColorSetting accent = add(new ColorSetting("Accent Color", 0xFFA855F7));
    private final NumberSetting animation = add(NumberSetting.decimal("Animation Intensity", 1.0, 0.0, 2.0, 0.25));
    private final BoolSetting reduced = add(new BoolSetting("Reduced Effects", false));
    private final BoolSetting glow = add(new BoolSetting("Glow", true));
    private final BoolSetting sounds = add(new BoolSetting("GUI Sounds", true));
    private final NumberSetting volume = add(NumberSetting.decimal("Sound Volume", 0.5, 0.0, 1.0, 0.1));
    private final NumberSetting guiScale = add(NumberSetting.decimal("GUI Scale", 1.0, 0.75, 2.0, 0.25));
    private final NumberSetting animSpeed = add(NumberSetting.decimal("Animation Speed", 1.0, 0.5, 2.0, 0.25));
    private final EnumSetting<UiSettings.Preset> preset = add(new EnumSetting<>("Performance Preset", UiSettings.Preset.BALANCED));
    private final NumberSetting notifySeconds = add(NumberSetting.decimal("Notification Duration (s)", 3.5, 1.0, 10.0, 0.5));

    public InterfaceModule() {
        super("Interface", "Theme, accent color, animations, sounds and GUI scale.", Category.SETTINGS);
        setEnabled(true);
    }

    @Override public boolean panicEligible() { return false; }

    /** Mirrors settings into the static runtime holder. */
    public void apply() {
        UiSettings.theme = theme.get();
        UiSettings.customAccent = customAccent.get() ? accent.get() : 0;
        UiSettings.animationIntensity = animation.asFloat();
        UiSettings.reducedEffects = reduced.get();
        UiSettings.glow = glow.get();
        UiSettings.guiSounds = sounds.get();
        UiSettings.soundVolume = volume.asFloat();
        UiSettings.guiScale = guiScale.asFloat();
        UiSettings.animationSpeed = animSpeed.asFloat();
        UiSettings.preset = preset.get();
        dev.nyxvault.util.Notifications.lifetime = Math.round(notifySeconds.get() * 1000.0);
    }

    @Override public void onTick() { apply(); }
}
