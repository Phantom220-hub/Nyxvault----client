package dev.nyxvault.module.player;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.EnumSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.ClickTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

import java.util.concurrent.ThreadLocalRandom;

public final class PlayerModules {
    private PlayerModules() { }

    /** Raises the vanilla brightness option; restores the previous value on disable. */
    public static final class Brightness extends Module {
        private final NumberSetting level = add(NumberSetting.decimal("Level", 1.0, 0.0, 1.0, 0.05));
        private Double previous;

        public Brightness() { super("Brightness", "Sets the vanilla brightness option (restored when disabled).", Category.VISUALS); }

        @Override protected void onEnable() {
            Minecraft mc = Minecraft.getInstance();
            previous = mc.options.gamma().get();
            mc.options.gamma().set(level.get());
        }

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            if (Math.abs(mc.options.gamma().get() - level.get()) > 1e-6) mc.options.gamma().set(level.get());
        }

        @Override protected void onDisable() {
            if (previous != null) Minecraft.getInstance().options.gamma().set(previous);
            previous = null;
        }
    }

    /** Keeps sprint active while moving forward, using vanilla sprint conditions. */
    public static final class AutoSprint extends Module {
        public AutoSprint() { super("Toggle Sprint", "Sprints automatically while you hold forward.", Category.MOVEMENT); }

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            var p = mc.player;
            if (p == null || mc.screen != null) return;
            if (mc.options.keyUp.isDown() && !p.horizontalCollision && !p.isUsingItem()
                    && !p.isCrouching() && p.getFoodData().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        }
    }

    /**
     * Hold-to-click helper: only clicks while YOU physically hold the chosen mouse button
     * and the module is enabled. Automated clicking may violate multiplayer server rules,
     * including on HolyWorld. Use at your own risk; disable immediately via its key or the panic key.
     */
    public static final class AutoClicker extends Module {
        public enum Button { LEFT, RIGHT }

        private final EnumSetting<Button> button = add(new EnumSetting<>("Button", Button.LEFT));
        private final NumberSetting cps = add(NumberSetting.decimal("CPS", 8.0, 1.0, 20.0, 0.5));
        private final BoolSetting variation = add(new BoolSetting("Timing Variation", true));
        private long nextClick;

        public AutoClicker() { super("AutoClicker", "Repeats a click while you hold the mouse button. May violate server rules!", Category.UTILITIES); }

        public boolean active() { return enabled(); }

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.screen != null) return;
            boolean held = button.get() == Button.LEFT ? mc.mouseHandler.isLeftPressed() : mc.mouseHandler.isRightPressed();
            if (!held) return;
            long now = System.currentTimeMillis();
            if (now < nextClick) return;
            double interval = 1000.0 / cps.get();
            if (variation.get()) interval *= 0.85 + ThreadLocalRandom.current().nextDouble() * 0.3;
            nextClick = now + (long) interval;
            // Only extra clicks beyond the real press are generated through the vanilla click path.
            if (button.get() == Button.LEFT) {
                KeyMapping.click(InputConstants.Type.MOUSE.getOrCreate(0));
                ClickTracker.recordLeft();
            } else {
                KeyMapping.click(InputConstants.Type.MOUSE.getOrCreate(1));
                ClickTracker.recordRight();
            }
        }
    }
}
