package dev.nyxvault.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Integer or decimal setting with min/max/step. */
public final class NumberSetting extends Setting<Double> {
    private final double min, max, step;
    private final boolean integer;

    public NumberSetting(String name, double def, double min, double max, double step, boolean integer) {
        super(name, def);
        this.min = min; this.max = max; this.step = step; this.integer = integer;
    }

    public static NumberSetting integer(String name, int def, int min, int max) {
        return new NumberSetting(name, def, min, max, 1, true);
    }

    public static NumberSetting decimal(String name, double def, double min, double max, double step) {
        return new NumberSetting(name, def, min, max, step, false);
    }

    public int asInt() { return (int) Math.round(value); }
    public float asFloat() { return value.floatValue(); }
    public double min() { return min; }
    public double max() { return max; }

    @Override public void set(Double v) { value = clamp(v); }

    private double clamp(double v) {
        double c = Math.max(min, Math.min(max, v));
        return integer ? Math.round(c) : Math.round(c / step) * step;
    }

    @Override public JsonElement toJson() { return new JsonPrimitive(value); }

    @Override public void fromJson(JsonElement e) {
        if (e != null && e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) {
            double d = e.getAsDouble();
            if (!Double.isNaN(d) && !Double.isInfinite(d)) value = clamp(d);
        }
    }

    @Override public String display() {
        return integer ? Integer.toString(asInt()) : String.format("%.2f", value);
    }

    @Override public void interact(int direction) { value = clamp(value + direction * step); }
}
