package dev.nyxvault.render;

/** Color themes. NYXVAULT SIGNATURE is the default. Values are ARGB. */
public enum Theme {
    NYXVAULT_SIGNATURE("NYXVAULT Signature", 0xF0050509, 0xF0101030, 0xFFA855F7, 0xFF60A5FA),
    DARK_PURPLE("Dark Purple", 0xF00A0610, 0xF0170B2A, 0xFF9333EA, 0xFFC084FC),
    CYBERPUNK_BLUE("Cyberpunk Blue", 0xF0030712, 0xF00A1A3A, 0xFF22D3EE, 0xFF3B82F6),
    MINIMAL_DARK("Minimal Dark", 0xF0101010, 0xF01A1A1A, 0xFFE5E5E5, 0xFF9CA3AF);

    public final String title;
    public final int background;
    public final int panel;
    public final int accent;
    public final int secondary;

    Theme(String title, int background, int panel, int accent, int secondary) {
        this.title = title;
        this.background = background;
        this.panel = panel;
        this.accent = accent;
        this.secondary = secondary;
    }
}
