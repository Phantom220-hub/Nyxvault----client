package dev.nyxvault.hud;

import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.module.combat.CombatState;
import dev.nyxvault.module.combat.TotemModules;
import dev.nyxvault.render.Draw;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.util.ClickTracker;
import dev.nyxvault.util.InventoryUtil;
import dev.nyxvault.util.SessionStats;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Additional HUD elements. All data shown is read from the client; nothing is guessed. */
public final class ExtraHudModules {
    private ExtraHudModules() { }

    private static final int WHITE = 0xFFFFFFFF;

    /** Multi-line panel that rebuilds its text at most every 200 ms. */
    abstract static class LinesElement extends HudModule {
        private final String[] lines = new String[10];
        private int n;
        private int w = 60;
        private long built;

        protected LinesElement(String name, String desc, Category cat, int x, int y) { super(name, desc, cat, x, y); }

        /** Fill {@code out} (max 10 lines) and return the number of lines. */
        protected abstract int build(Minecraft mc, String[] out);

        private void ensure(Minecraft mc) {
            long now = System.currentTimeMillis();
            if (n > 0 && now - built < 200) return;
            built = now;
            n = Math.max(1, Math.min(lines.length, build(mc, lines)));
            int mw = 40;
            for (int i = 0; i < n; i++) mw = Math.max(mw, mc.font.width(lines[i]));
            w = mw + 12;
        }

        @Override public int width(Minecraft mc) { ensure(mc); return w; }
        @Override public int height(Minecraft mc) { ensure(mc); return n * 11 + 6; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            ensure(mc);
            Draw.round(g, 0, 0, w, n * 11 + 6, a(UiSettings.theme.background));
            g.fill(0, 2, 2, n * 11 + 4, a(UiSettings.accent()));
            for (int i = 0; i < n; i++) g.drawString(mc.font, lines[i], 6, 4 + i * 11, a(WHITE), true);
        }
    }

    // ---------------------------------------------------------------- totems

    public static final class TotemHud extends HudModule {
        private final ItemStack icon = new ItemStack(Items.TOTEM_OF_UNDYING);

        public TotemHud() { super("Totem HUD", "Offhand totem state and total totem count.", Category.HUD, 130, 4); }
        @Override public int width(Minecraft mc) { return 56; }
        @Override public int height(Minecraft mc) { return 20; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            boolean off = TotemModules.Tracker.offhandHasTotem();
            Draw.round(g, 0, 0, 56, 20, a(UiSettings.theme.background));
            Draw.border(g, 0, 0, 56, 20, a(off ? 0xFF22C55E : 0xFFEF4444));
            g.renderItem(icon, 2, 2);
            g.drawString(mc.font, "x" + TotemModules.Tracker.count(), 22, 6, a(WHITE), true);
            g.drawString(mc.font, off ? "ON" : "OFF", 38, 6, a(off ? 0xFF22C55E : 0xFFEF4444), true);
        }
    }

    public static final class PopCounter extends HudModules.TextElement {
        public PopCounter() { super("Totem Pop Counter", "Your own totem pops this session (client-side detection).", 130, 28); }
        @Override protected String text(Minecraft mc) { return "Pops: " + SessionStats.pops; }
    }

    // ---------------------------------------------------------------- combat / player

    public static final class CombatHud extends LinesElement {
        public CombatHud() { super("Combat HUD", "Attack cooldown, confirmed hits, combo and CPS.", Category.HUD, 130, 46); }

        @Override protected int build(Minecraft mc, String[] out) {
            out[0] = "Cooldown " + Math.round(mc.player.getAttackStrengthScale(0f) * 100f) + "%";
            out[1] = "Hits " + SessionStats.hits + "  Combo " + CombatState.combo() + " (best " + SessionStats.maxCombo + ")";
            out[2] = "CPS " + ClickTracker.leftCps() + " | " + ClickTracker.rightCps();
            return 3;
        }
    }

    public static final class PlayerInfo extends LinesElement {
        public PlayerInfo() { super("Player Info", "Health, hunger, measured speed and dimension.", Category.HUD, 130, 90); }

        @Override protected int build(Minecraft mc, String[] out) {
            Player p = mc.player;
            out[0] = String.format("HP %.1f / %.0f", p.getHealth(), p.getMaxHealth());
            out[1] = "Food " + p.getFoodData().getFoodLevel();
            out[2] = String.format("Speed %.1f b/s", SessionStats.speed());
            out[3] = "Dim " + SessionStats.dimName(mc);
            return 4;
        }
    }

    public static final class SessionStatsHud extends LinesElement {
        private final BoolSetting reset = add(new BoolSetting("Reset Now", false));

        public SessionStatsHud() { super("Session Stats", "Time, distance, swings, confirmed hits and pops. Toggle 'Reset Now' to clear.", Category.HUD, 130, 146); }

        @Override public void onTick() {
            if (reset.get()) { SessionStats.reset(); reset.set(false); }
        }

        @Override protected int build(Minecraft mc, String[] out) {
            long s = SessionStats.elapsedSeconds();
            out[0] = String.format("Time %02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
            out[1] = String.format("Distance %.0f m", SessionStats.distance);
            out[2] = "Swings " + SessionStats.swings + "  Hits " + SessionStats.hits;
            out[3] = "Pops " + SessionStats.pops + "  Best combo " + SessionStats.maxCombo;
            return 4;
        }
    }

    // ---------------------------------------------------------------- world info

    public static final class CompassHud extends HudModule {
        private static final String[] NAMES = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        private static final float[] YAWS = {0f, 45f, 90f, 135f, 180f, -135f, -90f, -45f};

        public CompassHud() { super("Compass", "Heading strip with cardinal directions and bearing.", Category.HUD, 250, 4); }
        @Override public int width(Minecraft mc) { return 150; }
        @Override public int height(Minecraft mc) { return 14; }

        @Override protected void draw(GuiGraphics g, Minecraft mc) {
            Draw.round(g, 0, 0, 150, 14, a(UiSettings.theme.background));
            float yaw = Mth.wrapDegrees(mc.player.getYRot());
            for (int i = 0; i < NAMES.length; i++) {
                float d = Mth.wrapDegrees(YAWS[i] - yaw);
                if (Math.abs(d) > 58f) continue;
                int cx = 75 + Math.round(d / 58f * 70f);
                String s = NAMES[i];
                boolean main = s.length() == 1;
                g.drawString(mc.font, s, cx - mc.font.width(s) / 2, 3, a(main ? WHITE : 0xFF9CA3AF), true);
            }
            g.fill(74, 0, 76, 3, a(UiSettings.accent()));
            g.fill(74, 11, 76, 14, a(UiSettings.accent()));
            int bearing = Math.round(Mth.wrapDegrees(yaw + 180f) + 360f) % 360;
            String b = bearing + "°";
            g.drawString(mc.font, b, 150 - mc.font.width(b) - 3, 3, a(UiSettings.secondary()), true);
        }
    }

    public static final class ClockHud extends HudModules.TextElement {
        private String cached = "";
        private long key = -1;

        public ClockHud() { super("Clock", "Real time and in-game time.", 250, 22); }

        @Override protected String text(Minecraft mc) {
            LocalTime now = LocalTime.now();
            long dt = mc.level == null ? 0 : mc.level.getDayTime() % 24000L;
            long k = now.getHour() * 60L + now.getMinute() + (dt / 17) * 10000L;
            if (k != key) {
                key = k;
                long hour = (dt / 1000 + 6) % 24, min = (dt % 1000) * 60 / 1000;
                cached = String.format("%02d:%02d  |  MC %02d:%02d", now.getHour(), now.getMinute(), hour, min);
            }
            return cached;
        }
    }

    public static final class TargetBlockHud extends HudModules.TextElement {
        public TargetBlockHud() { super("Target Block", "Name and distance of the block you are looking at.", 250, 40); }

        @Override protected String text(Minecraft mc) {
            if (mc.hitResult instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
                String name = mc.level.getBlockState(bhr.getBlockPos()).getBlock().getName().getString();
                double d = mc.player.getEyePosition().distanceTo(bhr.getLocation());
                return String.format("%s  %.1fm", name, d);
            }
            return "No block targeted";
        }
    }

    public static final class LightLevelHud extends HudModules.TextElement {
        public LightLevelHud() { super("Light Level", "Block and sky light at your position.", 250, 58); }

        @Override protected String text(Minecraft mc) {
            BlockPos pos = mc.player.blockPosition();
            return "Light  block " + mc.level.getBrightness(LightLayer.BLOCK, pos)
                    + "  sky " + mc.level.getBrightness(LightLayer.SKY, pos);
        }
    }

    public static final class NearbyPlayers extends LinesElement {
        private final NumberSetting radius = add(NumberSetting.integer("Radius", 64, 8, 256));
        private final NumberSetting maxShown = add(NumberSetting.integer("Max Players", 5, 1, 9));
        private final List<Player> tmp = new ArrayList<>();

        public NearbyPlayers() { super("Nearby Players", "Players loaded on your client within a radius (name, distance, health).", Category.HUD, 250, 76); }

        @Override protected int build(Minecraft mc, String[] out) {
            tmp.clear();
            double r2 = (double) radius.asInt() * radius.asInt();
            for (Player p : mc.level.players()) {
                if (p != mc.player && mc.player.distanceToSqr(p) <= r2) tmp.add(p);
            }
            tmp.sort(Comparator.comparingDouble(p -> mc.player.distanceToSqr(p)));
            int n = Math.min(tmp.size(), maxShown.asInt());
            if (n == 0) { out[0] = "No players nearby"; return 1; }
            for (int i = 0; i < n; i++) {
                Player p = tmp.get(i);
                out[i] = String.format("%s  %.0fm  %.1f hp", p.getName().getString(), Math.sqrt(mc.player.distanceToSqr(p)), p.getHealth());
            }
            return n;
        }
    }

    public static final class ItemCounter extends LinesElement {
        private final BoolSetting totems = add(new BoolSetting("Totems", true));
        private final BoolSetting gapples = add(new BoolSetting("Golden Apples", true));
        private final BoolSetting pearls = add(new BoolSetting("Ender Pearls", true));
        private final BoolSetting arrows = add(new BoolSetting("Arrows", false));
        private final BoolSetting xp = add(new BoolSetting("XP Bottles", false));

        public ItemCounter() { super("Item Counter", "Counts of chosen items in your inventory.", Category.HUD, 250, 130); }

        @Override protected int build(Minecraft mc, String[] out) {
            Player p = mc.player;
            int n = 0;
            if (totems.get()) out[n++] = "Totems " + InventoryUtil.count(p, Items.TOTEM_OF_UNDYING);
            if (gapples.get()) out[n++] = "Golden Apples " + (InventoryUtil.count(p, Items.GOLDEN_APPLE) + InventoryUtil.count(p, Items.ENCHANTED_GOLDEN_APPLE));
            if (pearls.get()) out[n++] = "Ender Pearls " + InventoryUtil.count(p, Items.ENDER_PEARL);
            if (arrows.get()) out[n++] = "Arrows " + InventoryUtil.count(p, Items.ARROW);
            if (xp.get()) out[n++] = "XP Bottles " + InventoryUtil.count(p, Items.EXPERIENCE_BOTTLE);
            if (n == 0) out[n++] = "No items selected";
            return n;
        }
    }
}
