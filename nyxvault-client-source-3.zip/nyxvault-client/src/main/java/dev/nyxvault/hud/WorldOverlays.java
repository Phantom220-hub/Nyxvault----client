package dev.nyxvault.hud;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.UiSettings;
import dev.nyxvault.module.Category;
import dev.nyxvault.render.Draw;
import dev.nyxvault.render.WorldProjector;
import dev.nyxvault.setting.BoolSetting;
import dev.nyxvault.setting.ColorSetting;
import dev.nyxvault.setting.NumberSetting;
import dev.nyxvault.waypoint.Waypoint;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.PrimedTnt;

/** Overlays that are anchored to world positions or to the screen edges. */
public final class WorldOverlays {
    private WorldOverlays() { }

    private static void label(GuiGraphics g, Minecraft mc, String text, float x, float y, float scale, int color) {
        int w = mc.font.width(text);
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.fill(-w / 2 - 2, -1, w / 2 + 3, 10, 0x99000000); // dark backing keeps text readable on any background
        g.drawString(mc.font, text, -w / 2, 0, color, true);
        g.pose().popMatrix();
    }

    // ------------------------------------------------------------------ TNT

    /**
     * Shows the fuse of primed TNT using the fuse value the client holds for that entity.
     * It is a client-side value and can drift slightly from the server during lag. TNT behavior
     * is never changed.
     */
    public static final class TntCountdown extends OverlayModule {
        private final NumberSetting maxDistance = add(NumberSetting.integer("Max Distance", 32, 5, 96));
        private final NumberSetting scale = add(NumberSetting.decimal("Label Scale", 1.0, 0.75, 2.0, 0.25));
        private final BoolSetting showDistance = add(new BoolSetting("Show Distance", true));
        private final ColorSetting safe = add(new ColorSetting("Color", 0xFFEAB308));
        private final ColorSetting danger = add(new ColorSetting("Danger Color", 0xFFEF4444));

        public TntCountdown() { super("TNT Countdown", "Fuse timer above primed TNT (client-side value).", Category.WORLD); }

        @Override public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
            if (mc.level == null || mc.player == null) return;
            double max2 = (double) maxDistance.asInt() * maxDistance.asInt();
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof PrimedTnt tnt)) continue;
                double d2 = mc.player.distanceToSqr(e);
                if (d2 > max2) continue;
                if (!WorldProjector.project(e.getX(), e.getY() + e.getBbHeight() + 0.5, e.getZ())) continue;
                if (!WorldProjector.onScreen(40f)) continue;
                int fuse = tnt.getFuse();
                String text = String.format("%.1fs", Math.max(0, fuse) / 20.0)
                        + (showDistance.get() ? String.format("  %.0fm", Math.sqrt(d2)) : "");
                label(g, mc, text, WorldProjector.out[0], WorldProjector.out[1], scale.asFloat(),
                        fuse <= 20 ? danger.get() : safe.get());
            }
        }
    }

    // ------------------------------------------------------------------ waypoints

    /** World labels for saved waypoints: diamond marker, name and distance, same dimension only. */
    public static final class WaypointMarkers extends OverlayModule {
        private final NumberSetting maxDistance = add(NumberSetting.integer("Max Distance", 2000, 50, 20000));
        private final BoolSetting names = add(new BoolSetting("Show Names", true));
        private final BoolSetting distance = add(new BoolSetting("Show Distance", true));
        private final BoolSetting activeOnly = add(new BoolSetting("Active Waypoint Only", false));
        private final NumberSetting scale = add(NumberSetting.decimal("Label Scale", 1.0, 0.75, 2.0, 0.25));
        private final NumberSetting markerSize = add(NumberSetting.integer("Marker Size", 4, 2, 8));

        public WaypointMarkers() {
            super("Waypoint Markers", "Draws waypoints in the world with name and distance.", Category.WORLD);
            setEnabled(true);
        }

        @Override public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
            if (mc.level == null || mc.player == null) return;
            String dim = mc.level.dimension().toString();
            Waypoint active = NyxvaultClient.waypoints().active();
            double max = maxDistance.asInt();
            for (Waypoint w : NyxvaultClient.waypoints().all()) {
                if (!w.enabled || !w.dimension.equals(dim)) continue;
                if (activeOnly.get() && w != active) continue;
                double d = w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ());
                if (d > max) continue;
                if (!WorldProjector.project(w.x, w.y + 1.5, w.z) || !WorldProjector.onScreen(30f)) continue;
                float x = WorldProjector.out[0], y = WorldProjector.out[1];
                int s = markerSize.asInt() + (w == active ? 2 : 0);
                int col = w.color | 0xFF000000;
                for (int r = -s; r <= s; r++) { // filled diamond
                    int half = s - Math.abs(r);
                    g.fill(Math.round(x) - half, Math.round(y) + r, Math.round(x) + half + 1, Math.round(y) + r + 1, col);
                }
                String text = (names.get() ? w.name : "") + (names.get() && distance.get() ? "  " : "")
                        + (distance.get() ? String.format("%.0fm", d) : "");
                if (!text.isEmpty()) label(g, mc, text, x, y - s - 14, scale.asFloat(), 0xFFFFFFFF);
            }
        }
    }

    // ------------------------------------------------------------------ damage flash

    /** Brief crisp red border when you take damage. Visual only. */
    public static final class DamageFlash extends OverlayModule {
        private final ColorSetting color = add(new ColorSetting("Color", 0xFFEF4444));
        private final NumberSetting duration = add(NumberSetting.integer("Duration (ms)", 350, 100, 1000));
        private final NumberSetting thickness = add(NumberSetting.integer("Thickness", 24, 6, 60));
        private final NumberSetting intensity = add(NumberSetting.decimal("Intensity", 0.6, 0.1, 1.0, 0.05));
        private int lastHurt;
        private long start;

        public DamageFlash() { super("Damage Flash", "Short red screen-edge flash when you are hurt.", Category.VISUALS); }

        @Override public void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta) {
            if (mc.player == null) return;
            int ht = mc.player.hurtTime;
            long now = System.currentTimeMillis();
            if (ht > 0 && lastHurt == 0) start = now;
            lastHurt = ht;
            if (start == 0) return;
            long age = now - start;
            if (age > duration.asInt()) return;
            float fade = 1f - age / (float) duration.asInt();
            float a = fade * intensity.asFloat() * (UiSettings.reducedEffects ? 0.5f : 1f);
            int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
            int t = thickness.asInt();
            for (int i = 1; i <= 4; i++) { // stacked layers: strongest at the edge, no blur
                int th = t * i / 4;
                int c = Draw.alpha(color.get(), a * 0.28f);
                g.fill(0, 0, sw, th, c);
                g.fill(0, sh - th, sw, sh, c);
                g.fill(0, th, th, sh - th, c);
                g.fill(sw - th, th, sw, sh - th, c);
            }
        }
    }
}
