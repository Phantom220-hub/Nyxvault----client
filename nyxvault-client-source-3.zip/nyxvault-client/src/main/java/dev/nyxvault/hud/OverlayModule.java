package dev.nyxvault.hud;

import dev.nyxvault.module.Category;
import dev.nyxvault.module.Module;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** A module that draws something on the in-game overlay. */
public abstract class OverlayModule extends Module {
    protected OverlayModule(String name, String description, Category category) {
        super(name, description, category);
    }

    public abstract void renderOverlay(GuiGraphics g, Minecraft mc, DeltaTracker delta);
}
