package dev.nyxvault.waypoint;

import dev.nyxvault.NyxvaultClient;
import dev.nyxvault.config.ConfigManager;
import dev.nyxvault.util.Notifications;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

/** Waypoint storage, selection, search and arrival-based auto-removal. */
public final class WaypointManager {
    public enum RemoveMode { ACTIVE_ONLY, ALL_REACHED }

    private final List<Waypoint> waypoints = new CopyOnWriteArrayList<>();
    private String activeId;

    // Auto-removal settings (disabled by default).
    public boolean autoRemove = false;
    public RemoveMode removeMode = RemoveMode.ACTIVE_ONLY;
    public double defaultRadius = 3.0;
    public boolean notify = true;
    public boolean sound = true;

    public List<Waypoint> all() { return List.copyOf(waypoints); }

    public Waypoint add(Waypoint w) {
        if (w.radius <= 0) w.radius = defaultRadius;
        waypoints.add(w);
        if (activeId == null) activeId = w.id;
        ConfigManager.requestSave();
        return w;
    }

    public Waypoint addHere(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return null;
        Waypoint w = new Waypoint();
        w.name = name;
        w.x = mc.player.getX();
        w.y = mc.player.getY();
        w.z = mc.player.getZ();
        w.dimension = mc.level.dimension().toString();
        w.radius = defaultRadius;
        return add(w);
    }

    public boolean remove(String idOrName) {
        Waypoint w = find(idOrName);
        if (w == null) return false;
        removeInternal(w);
        return true;
    }

    private void removeInternal(Waypoint w) {
        waypoints.remove(w);
        if (w.id.equals(activeId)) activeId = null;
        ConfigManager.requestSave();
    }

    public Waypoint find(String idOrName) {
        for (Waypoint w : waypoints) if (w.id.equals(idOrName)) return w;
        for (Waypoint w : waypoints) if (w.name.equalsIgnoreCase(idOrName)) return w;
        return null;
    }

    public Waypoint active() {
        if (activeId == null) return null;
        for (Waypoint w : waypoints) if (w.id.equals(activeId)) return w;
        return null;
    }

    public String activeId() { return activeId; }

    public boolean select(String idOrName) {
        Waypoint w = find(idOrName);
        if (w == null) return false;
        activeId = w.id;
        ConfigManager.requestSave();
        return true;
    }

    public void setActiveId(String id) { this.activeId = id; }

    public void replaceAll(List<Waypoint> list, String active) {
        waypoints.clear();
        waypoints.addAll(list);
        this.activeId = active;
    }

    public List<Waypoint> search(String query, boolean byDistance) {
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT);
        List<Waypoint> out = new ArrayList<>();
        for (Waypoint w : waypoints) {
            if (q.isEmpty() || w.name.toLowerCase(Locale.ROOT).contains(q)
                    || w.group.toLowerCase(Locale.ROOT).contains(q)
                    || w.description.toLowerCase(Locale.ROOT).contains(q)) out.add(w);
        }
        Minecraft mc = Minecraft.getInstance();
        if (byDistance && mc.player != null) {
            out.sort(Comparator.comparingDouble(w -> w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ())));
        } else {
            out.sort(Comparator.comparing(w -> w.name.toLowerCase(Locale.ROOT)));
        }
        return out;
    }

    /**
     * Called every client tick. A waypoint is removed only when the player is in the same
     * dimension and within the arrival radius; dimension changes / unloads never remove anything.
     */
    public void tick(Minecraft mc) {
        if (!autoRemove || mc.player == null || mc.level == null) return;
        String dim = mc.level.dimension().toString();
        List<Waypoint> reached = new ArrayList<>();
        Waypoint act = active();
        for (Waypoint w : waypoints) {
            if (!w.enabled || !w.autoRemove || !w.dimension.equals(dim)) continue;
            if (removeMode == RemoveMode.ACTIVE_ONLY && w != act) continue;
            if (w.distanceTo(mc.player.getX(), mc.player.getY(), mc.player.getZ()) <= w.radius) reached.add(w);
        }
        if (reached.isEmpty()) return;
        for (Waypoint w : reached) {
            if (!waypoints.contains(w)) continue; // already removed, prevents duplicates
            removeInternal(w);                    // also clears active selection => marker/HUD disappear
            if (notify) Notifications.push("WAYPOINT REACHED: " + w.name);
            if (sound) mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f));
            NyxvaultClient.LOGGER.info("Waypoint reached and removed: {}", w.name);
        }
    }
}
