package dev.nyxvault.waypoint;

import java.util.UUID;

/** A saved destination in real world coordinates. Plain data, serialized by Gson. */
public final class Waypoint {
    public String id = UUID.randomUUID().toString();
    public String name = "Waypoint";
    public String description = "";
    public String group = "Default";
    public String icon = "diamond";
    public String dimension = "";
    public double x, y, z;
    public int color = 0xFFA855F7;
    public boolean enabled = true;
    /** Per-waypoint auto-removal opt-in (also requires the global setting). */
    public boolean autoRemove = true;
    /** Arrival radius in blocks. */
    public double radius = 3.0;

    public double distanceTo(double px, double py, double pz) {
        double dx = x - px, dy = y - py, dz = z - pz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Eight-way arrow pointing from the player toward this waypoint, relative to where the player looks. */
    public String arrow(double px, double pz, float yawDeg) {
        double angle = Math.toDegrees(Math.atan2(-(x - px), z - pz)); // Minecraft yaw convention
        double rel = ((angle - yawDeg) % 360 + 540) % 360 - 180;      // -180..180, 0 = straight ahead
        String[] arrows = {"^", "^>", ">", "v>", "v", "<v", "<", "<^"};
        int idx = (int) Math.round(rel / 45.0);
        return arrows[((idx % 8) + 8) % 8];
    }

    public boolean valid() {
        return name != null && !name.isBlank() && dimension != null
                && Double.isFinite(x) && Double.isFinite(y) && Double.isFinite(z)
                && radius > 0 && radius <= 1000;
    }
}
